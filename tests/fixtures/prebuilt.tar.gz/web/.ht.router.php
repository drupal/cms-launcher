<?php

// A mocked version of .ht.router.php, which is normally placed here by
// Drupal's scaffolding plugin.

require $_SERVER['SCRIPT_FILENAME'];
