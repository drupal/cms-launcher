<!doctype html>
<body>
  <h1>A prebuilt archive worked!</h1>
  <p>Running PHP via <?php echo PHP_SAPI; ?>.</p>
</body>
